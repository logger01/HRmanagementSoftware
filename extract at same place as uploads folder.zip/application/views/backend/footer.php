<!-- Footer -->
<footer class="main">

	&copy; 2016 <strong><?php echo $system_name; ?> | Version 1.4</strong> Developed by <a href="http://creativeitem.com" target="_blank">Creativeitem</a>

</footer>
